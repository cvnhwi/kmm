# KMM: ĐỌC FILE NÀY TRƯỚC (gói handoff 2026-10-04)

Đây là gói tổng hợp toàn bộ dự án MV "KHÔNG MỘT MÌNH" (KMM) tới ngày 2026-10-04. Ném cả gói vào box chat mới rồi dán lời nhắn ở mục 4.

## 1. Thứ tự đọc
1. `docs/HANDOFF_2026-10-04_STYLE_A_B.md`: trạng thái mới nhất, hai style A/B, cảnh chuyển A→B, việc còn mở.
2. `docs/KMM_RULES_SUMMARY.md`: toàn bộ luật cứng (áp cho style B, phần lớn dùng chung).
3. `docs/HANDOFF_GUIDE.md`: ID media, thông số Higgsfield, cách làm việc.
4. `docs/STYLE_GUIDE_A.md` và `docs/STYLE_A_SAMPLE_PROMPT.md`: style A (đời thực, 01_Mai).
5. `docs/STYLE_GUIDE_B.md`, `docs/CAMERA_LIBRARY_B.md` (mục 8 = director pass): style B (fantasy).
6. `docs/option_A2B_scene_hem_transition.md`: cảnh đang làm, đủ v1→v4, có job ID.
7. `docs/REUPLOAD_NEW_ACCOUNT.md`: log ID của account Higgsfield mới.
8. `skills/`: hai skill viết prompt (`kmm-fantasy-video-prompt` và `cinematic-director`). `docs/KMM_FANTASY_VIDEO_PROMPT_SKILL.md` là bản sao của skill fantasy.

## 2. Tóm tắt 30 giây
- User: Huy PD (Purple Studio / FLEX Films). Trả lời **tiếng Việt**, viết prompt **tiếng Anh**. Thiếu thông tin thì tự chọn rồi báo rõ đã chọn gì.
- Higgsfield: `seedance_2_5`, `omni_reference`, draft, 480p, 16:9, `generate_audio: true`. **Chỉ tiếng động, KHÔNG nhạc.** `declined_preset_id 24bae836-2c4a-48e0-89b6-49fcc0b21612`. **Mọi generation vào folder MV KMM `11749213-086c-4a29-a963-b5a064eb4af7`.**
- **STYLE A** (đời thực, vẽ tay, ánh sáng ẤM): video DAILY.mp4 `2535cacf-3f55-4f47-9e56-38bec54122e6`, Mai 01_Mai `fae9baae-3a83-4f65-bfe8-ee32fcc94a78`.
- **STYLE B** (fantasy, 3D bóng, cyan-teal LẠNH): video `24430dd0-a7ec-4d5c-a555-46abfb7600a1`, Mai fantasy `0d56fcb2-47cc-4271-b785-c73f4ab9a17b`.
- Quy trình mỗi lần gen:
  1. `generate_video_batch`.
  2. Viết file plan (Status SUBMITTED kèm job ID), commit và push.
  3. Đặt `send_later` khoảng 8 phút.
  4. Khi job xong: `jobs_wait`, rồi gửi link.
  5. Đổi Status thành COMPLETED, commit.
- Không xem được video/ảnh thì ghi "chưa kiểm tra nội dung". Muốn tự xem thì dùng sandbox Higgsfield (ffmpeg cắt khung hình, chuyển base64, decode rồi Read); chi tiết ở mục 3 của file handoff.
- Git: repo `cvnhwi/kmm`, branch `claude/busy-hawking-7f4dok`, không tạo PR.

## 3. Việc dang dở
- 3 job v4 của cảnh chuyển A→B chưa kiểm tra: `63cb55e7-be58-40d9-895e-c0f44d5aa553` (orbit sửa), `4197748d-ec37-42c3-b41c-4ab904e13e7c` (vũng nước), `9b356ba6-5280-4a02-963a-72203975c88e` (sóng từ cổng).
- Lỗi cần nhớ: v3 bị "không rõ style A" vì đêm tối và render 3D bóng. Style A phải ấm, sáng rõ và có chất vẽ tay.

## 4. Lời nhắn dán vào box chat mới
```
Tiếp tục dự án MV KMM. Đọc file 00_DOC_TRUOC.md trong gói zip trước, rồi theo thứ tự đọc trong đó. Repo cvnhwi/kmm, branch claude/busy-hawking-7f4dok. Trả lời tiếng Việt, prompt tiếng Anh. Style A = DAILY.mp4 2535cacf-3f55-4f47-9e56-38bec54122e6 + 01_Mai fae9baae-3a83-4f65-bfe8-ee32fcc94a78; Style B = Fantasy.mp4 24430dd0-a7ec-4d5c-a555-46abfb7600a1 + Mai fantasy 0d56fcb2-47cc-4271-b785-c73f4ab9a17b. Mọi gen vào folder MV KMM 11749213-086c-4a29-a963-b5a064eb4af7. Việc đầu tiên: kiểm tra 3 job v4.
```
